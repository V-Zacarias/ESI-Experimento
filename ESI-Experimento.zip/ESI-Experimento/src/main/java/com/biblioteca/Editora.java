package com.biblioteca;
public class Editora {    
    
    public String nome;

    public Editora() {

    }

    public Editora(String nome) {
        this.nome = nome;
    }
}
